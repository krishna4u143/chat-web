<html lang="en">

<head>
    <title>Chats</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <style>
        .box-centered {
            position: absolute;
            top: 30%;
            left: 45%;
        }

        p {
            font-size: 25px;
            font-weight: 600;
        }
    </style>

</head>

<body>
    <div class="container">
        <div class="box-centered">
            <p>Select a User</p>
            <button type="button" onclick="setUser(1)"> User 1 </button>
            <button type="button" onclick="setUser(2)"> User 2 </button>
            <button type="button" onclick="setUser(3)"> User 3 </button>
        </div>
    </div>
</body>

</html>
<script>
    function setUser(val) {
        var id = val
        $.ajax({
            url: "set_user",
            method: "POST",
            data: {
                user_id: id
            },
            success: function(data) {
                window.location = "chatpage"
            }
        })
    }
</script>