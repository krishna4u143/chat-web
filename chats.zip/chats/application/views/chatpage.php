<html lang="en">

<head>
    <title>Chat Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

</head>

<body>
    <div class="container d-flex h-100">

        <div class="col-6 mt-4">
            <p>Send message To</p>
            <?php foreach ($users as $us) { ?>
                <button type="button" onclick="senduser(<?= $us ?>)">User <?= $us ?></button>
            <?php } ?>

            <p class="mt-4">Selected User : User <?= $this->session->userdata('user_id') ?></p>
            <p class="mt-4">Send message to : <span id="senduser_id"></span></p>

            <a href="/chats/endchat">
                <button> End Chat</button>
            </a>
        </div>
        <div class="col-6 p-4 h-75">
            <div class="p-2 border br-8 d-flex h-100" id="message_box" style="flex-direction: column;overflow: auto;">
                <!-- <div class="row m-0 text-right">
                    <p class="w-100">Test1</p>
                </div>
                <div class="row m-0 text-left">
                    <p class="w-100">Test2</p>
                </div>
                <div class="row m-0 text-right">
                    <p class="w-100">Test1</p>
                </div>
                <div class="row m-0 text-left">
                    <p class="w-100">Test2</p>
                </div> -->
            </div>
            <div class="d-flex">
                <input class="w-100" placeholder="Send Something...." type="text" name="message_text" id="message_text">
                <button type="button" onclick="sendmessage()"> Send</button>
            </div>

        </div>
    </div>

</body>

</html>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-database.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-analytics.js"></script>
<script>
    var firebaseConfig = {
        apiKey: "AIzaSyCgUkaGAfCgPn9DtR2wWFa8fJeRxPl9b-E",
        authDomain: "chat-test-16ed0.firebaseapp.com",
        projectId: "chat-test-16ed0",
        storageBucket: "chat-test-16ed0.appspot.com",
        messagingSenderId: "910331684997",
        appId: "1:910331684997:web:213ad68402d421c14761ec"
    };

    var firebase = firebase.initializeApp(firebaseConfig);
    var sender = "<?= $this->session->userdata('user_id'); ?>"
    var receiver = ''


    function senduser(id) {
        receiver = "" + id
        $('#senduser_id').html('User' + id)
        $('#message_box').html('')
        firebase.database().ref("chats").on('value', function(snapshot) { // Show the messages between the users
            var items = snapshot.val()
            for (const item in items) {
                if ((items[item].sender == receiver) && (items[item].receiver == sender)) {
                    var sendmsg = ' <div class="row m-0 text-left"><p class="messagetext w-100">' + items[item].message + '</p></div>'
                    $('#message_box').append(sendmsg)
                } else if ((items[item].sender == sender) && (items[item].receiver == receiver)) {
                    var sendmsg = ' <div class="row m-0 text-right"><p class="messagetext w-100">' + items[item].message + '</p></div>'
                    $('#message_box').append(sendmsg)
                }
            }
            firebase.database().ref("chats").off("value");
        });
    }

    firebase.database().ref("chats").on("child_added", function(snapshot) { // to show the New message has been added 
        if ((snapshot.val().sender == receiver) && (snapshot.val().receiver == sender)) {
            var sendmsg = ' <div class="row m-0 text-left"><p class="messagetext w-100">' + snapshot.val().message + '</p></div>'
            $('#message_box').append(sendmsg)
        } else if ((snapshot.val().sender == sender) && (snapshot.val().receiver == receiver)) {
            var sendmsg = ' <div class="row m-0 text-right"><p class="messagetext w-100">' + snapshot.val().message + '</p></div>'
            $('#message_box').append(sendmsg)
        }
    });



    function sendmessage() {
        if (receiver != '') {
            var text = $('#message_text').val();

            // var sendmsg = ' <div class="row m-0 text-right"><p class="messagetext w-100">' + text + '</p></div>'
            // if (text != "") {
            //     $('#message_box').append(sendmsg)
            //     $('#message_text').val('')
            // }

            if (text != "") {
                $('#message_text').val('')
                firebase.database().ref("chats").push().set({ // To send the data into the firebase database
                    "message": text,
                    "sender": sender,
                    "receiver": receiver,
                });
            }
        } else {
            alert("Please select a user to message")
        }
    }
</script>