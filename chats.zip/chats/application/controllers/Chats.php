<?php

class Chats extends CI_Controller
{

    function __construct()
    {
        // this is your constructor
        parent::__construct();
        $this->load->helper('url');
    }

    public function index()
	{
		if ($this->session->userdata('user_id') && strlen($this->session->userdata('user_id')) > 0) {
			redirect('/chatpage');
		} else {
			$this->load->view('index');
		}
	}

	public function set_user()
	{
		$user_id = $this->input->post('user_id');
		$this->session->set_userdata('user_id', $user_id);

		return true;
	}

	public function chatpage()
	{
		if ($this->session->userdata('user_id') && strlen($this->session->userdata('user_id')) > 0) {

			$user_id = $this->session->userdata('user_id');
			if ($user_id == 1)
				$data['users'] = [2, 3];
			else if ($user_id == 2)
				$data['users'] = [1, 3];
			else
				$data['users'] = [1, 2];

			$this->load->view('chatpage', $data);
		} else {
			redirect('/');
		}
	}

	public function endchat(){
		$this->session->sess_destroy();
		redirect('/');
	}
}

?>